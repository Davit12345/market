package kh.com.camarket.dao;

import kh.com.camarket.model.CustomerOrder;

/**
 * Created by Yuth on 4/6/2017.
 */
public interface CustomerOrderDao {
    void addCustomerOrder(CustomerOrder customerOrder);
}
